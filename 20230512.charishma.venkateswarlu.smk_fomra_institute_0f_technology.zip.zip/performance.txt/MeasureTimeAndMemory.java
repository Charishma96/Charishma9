import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryUsage;

public class MeasureTimeAndMemory {
    public static void main(String[] args) {
        // measure start time
        long startTime = System.nanoTime();

        // your script code goes here

        // measure end time
        long endTime = System.nanoTime();

        // calculate time taken
        long timeTaken = endTime - startTime;

        // calculate memory used
        MemoryUsage memoryUsage = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
        long memoryUsed = memoryUsage.getUsed() / 1024 / 1024;

        // write results to file
        try (PrintWriter writer = new PrintWriter(new FileWriter("result.txt"))) {
            writer.printf("Time taken: %d milliseconds%n", timeTaken / 1_000_000);
            writer.printf("Memory used: %d MB%n", memoryUsed);
        } catch (IOException e) {
            e.printStackTrace();
}
}
}
